var searchData=
[
  ['baud_5frate_202',['baud_rate',['../structlink__layer.html#aa16f252d7ab880465b2a5b4ebe68efb1',1,'link_layer']]]
];
