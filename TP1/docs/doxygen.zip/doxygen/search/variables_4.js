var searchData=
[
  ['num_5ftransmissions_203',['num_transmissions',['../structlink__layer.html#a0f92a06ffa0057c680b19e2ff9556000',1,'link_layer']]]
];
