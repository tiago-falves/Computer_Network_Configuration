var searchData=
[
  ['num_5ftransmissions_266',['NUM_TRANSMISSIONS',['../connection_8h.html#acd47df5d3b130dcf973431717ae02fad',1,'connection.h']]]
];
