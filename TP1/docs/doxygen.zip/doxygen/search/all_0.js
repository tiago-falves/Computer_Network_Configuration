var searchData=
[
  ['_5fposix_5fsource_0',['_POSIX_SOURCE',['../connection_8h.html#ac3d144aa01e765a1fae62ab5491c7cc1',1,'connection.h']]]
];
