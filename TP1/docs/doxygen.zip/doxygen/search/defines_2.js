var searchData=
[
  ['baudrate_231',['BAUDRATE',['../connection_8h.html#a734bbab06e1a9fd2e5522db0221ff6e3',1,'connection.h']]],
  ['bcc1_5ferr_5fprob_232',['BCC1_ERR_PROB',['../message_8h.html#ac8e7d94964eb02890474c2c7e0ba8cff',1,'message.h']]],
  ['bcc2_5ferr_5fprob_233',['BCC2_ERR_PROB',['../message_8h.html#a2bcf80f6fa57a0df2768bf177f85106e',1,'message.h']]]
];
