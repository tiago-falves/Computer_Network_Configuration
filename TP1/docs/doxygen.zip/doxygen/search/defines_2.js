var searchData=
[
  ['baudrate_226',['BAUDRATE',['../connection_8h.html#a734bbab06e1a9fd2e5522db0221ff6e3',1,'connection.h']]]
];
