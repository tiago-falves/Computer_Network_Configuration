var searchData=
[
  ['num_5ftransmissions_86',['num_transmissions',['../structlink__layer.html#a0f92a06ffa0057c680b19e2ff9556000',1,'link_layer::num_transmissions()'],['../connection_8h.html#acd47df5d3b130dcf973431717ae02fad',1,'NUM_TRANSMISSIONS():&#160;connection.h']]]
];
