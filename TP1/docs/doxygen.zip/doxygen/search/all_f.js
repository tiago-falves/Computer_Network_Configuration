var searchData=
[
  ['readmessage_105',['readMessage',['../message_8h.html#a471d8917ad453dfe31de846c857de863',1,'message.h']]],
  ['receptor_106',['RECEPTOR',['../utils_8h.html#aab168383a1b59ad1de6d277449d68cd2a126c2d6c3bd0c0240ddeb54da90e47d3',1,'utils.h']]],
  ['rej_107',['REJ',['../message_8h.html#a2f1f5766b318ab3fbe3c8e371d7428e0',1,'message.h']]],
  ['resend_5fdelay_108',['RESEND_DELAY',['../protocol_8h.html#abdb489822bfbe4ad1a1377e0e15fdcba',1,'protocol.h']]],
  ['reset_5falarm_109',['reset_alarm',['../message_8h.html#a4aaa8ba21487e980879c22cc3e2213a9',1,'message.h']]],
  ['retrievefile_110',['retrieveFile',['../application_8h.html#ab42ebf7f585fc522adb8c8ecff6281d4',1,'application.h']]],
  ['role_111',['role',['../structarguments.html#add9721824b77f84d752dc0a2e73de2c6',1,'arguments']]],
  ['rr_112',['RR',['../message_8h.html#a482a89c3c8a0a7c084a37d8c8f235b77',1,'message.h']]]
];
