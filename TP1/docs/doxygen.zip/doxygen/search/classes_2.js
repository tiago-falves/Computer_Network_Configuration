var searchData=
[
  ['data_5fstuff_140',['data_stuff',['../structdata__stuff.html',1,'']]],
  ['data_5fstuffing_5ft_141',['data_stuffing_t',['../structdata__stuffing__t.html',1,'']]]
];
