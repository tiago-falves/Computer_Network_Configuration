var searchData=
[
  ['data_204',['data',['../structdata__stuff.html#a1e345544641c89dc726a16a7914c9ef5',1,'data_stuff']]],
  ['data_5fblock_5fsize_205',['data_block_size',['../structarguments.html#ae29f6ac0907cf01a3c7b2c1565d423eb',1,'arguments']]],
  ['data_5fsize_206',['data_size',['../structdata__stuff.html#a9864ee97379f67561257cf71f3915f94',1,'data_stuff']]]
];
