var searchData=
[
  ['sendcontrolpacket_184',['sendControlPacket',['../application_8h.html#afe1844bf958118a6cd8f8cc17eda9679',1,'application.h']]],
  ['senddatapacket_185',['sendDataPacket',['../application_8h.html#ab660a74a72a0af3fe372d5c5cf9b1ce8',1,'application.h']]],
  ['sendfile_186',['sendFile',['../application_8h.html#aef3a6b92327c11dc43e2e75c4717b2dd',1,'application.h']]],
  ['setblocksize_187',['setBlockSize',['../message_8h.html#a53df1f4cef4b404423da26b8d27c3bdd',1,'message.h']]],
  ['stuffdata_188',['stuffData',['../data__stuffing_8h.html#a449331bdbbc9399995dcb40d399cf042',1,'data_stuffing.h']]]
];
