var searchData=
[
  ['rej_274',['REJ',['../message_8h.html#a2f1f5766b318ab3fbe3c8e371d7428e0',1,'message.h']]],
  ['resend_5fdelay_275',['RESEND_DELAY',['../protocol_8h.html#abdb489822bfbe4ad1a1377e0e15fdcba',1,'protocol.h']]],
  ['rr_276',['RR',['../message_8h.html#a482a89c3c8a0a7c084a37d8c8f235b77',1,'message.h']]]
];
