var searchData=
[
  ['open_5fconnection_173',['open_connection',['../connection_8h.html#a85feb05a9d6dbbf93417511b8bb85acf',1,'connection.h']]]
];
