var searchData=
[
  ['llclose_174',['llclose',['../protocol_8h.html#a343e4b5928516727236a390a25f28c77',1,'protocol.h']]],
  ['llopen_175',['llopen',['../protocol_8h.html#aee2e24395c70355414f04486c3c0723c',1,'protocol.h']]],
  ['llread_176',['llread',['../protocol_8h.html#a83125bdb92acfac65a4b2f65451b93ad',1,'protocol.h']]],
  ['llwrite_177',['llwrite',['../protocol_8h.html#ab933f9b019db064b2204881b405c58ce',1,'protocol.h']]]
];
