var searchData=
[
  ['size_207',['size',['../structctrl__packet.html#a58c9e9a36eb34efcea140b082325b5f0',1,'ctrl_packet']]],
  ['stuffed_5fdata_208',['stuffed_data',['../structdata__stuffing__t.html#a157932592240cd5245b616ebe4389816',1,'data_stuffing_t']]],
  ['stuffed_5fdata_5fsize_209',['stuffed_data_size',['../structdata__stuffing__t.html#ac041ceb1541139fe607876eff3393c96',1,'data_stuffing_t']]]
];
