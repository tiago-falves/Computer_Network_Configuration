var searchData=
[
  ['layer_5ftimeout_75',['LAYER_TIMEOUT',['../connection_8h.html#a1d6c9cd3110a852cb0b6b6586555e330',1,'connection.h']]],
  ['link_5flayer_76',['link_layer',['../structlink__layer.html',1,'']]],
  ['llclose_77',['llclose',['../protocol_8h.html#a343e4b5928516727236a390a25f28c77',1,'protocol.h']]],
  ['llopen_78',['llopen',['../protocol_8h.html#aee2e24395c70355414f04486c3c0723c',1,'protocol.h']]],
  ['llread_79',['llread',['../protocol_8h.html#a83125bdb92acfac65a4b2f65451b93ad',1,'protocol.h']]],
  ['llwrite_80',['llwrite',['../protocol_8h.html#ab933f9b019db064b2204881b405c58ce',1,'protocol.h']]]
];
