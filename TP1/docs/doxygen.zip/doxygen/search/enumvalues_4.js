var searchData=
[
  ['emissor_217',['EMISSOR',['../utils_8h.html#aab168383a1b59ad1de6d277449d68cd2a0f7b0d99e976c5d9d611c7c32fe13cd2',1,'utils.h']]]
];
