var searchData=
[
  ['layer_5ftimeout_258',['LAYER_TIMEOUT',['../connection_8h.html#a1d6c9cd3110a852cb0b6b6586555e330',1,'connection.h']]]
];
